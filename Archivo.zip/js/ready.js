$(document).ready(function(){
    $('.parallax-window').parallax({imageSrc: 'images/confeti.svg'});
}); 